# -*- coding: utf-8 -*-
# @Date:   2015-01-05 15:50:18
# @Last Modified time: 2015-04-17 08:44:09

import BaseHTTPServer
import BitServer

HOST_NAME = '127.0.0.1'
# HOST_NAME = '0.0.0.0'
PORT_NUMBER = 8018



if __name__ == '__main__':

    server_class = BaseHTTPServer.HTTPServer
    httpd = server_class((HOST_NAME, PORT_NUMBER), BitServer.MyHandler)
    httpd.serve_forever()