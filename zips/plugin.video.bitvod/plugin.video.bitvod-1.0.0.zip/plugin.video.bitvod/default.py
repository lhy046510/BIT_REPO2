#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author: callnothing
# @Date:   2015-04-09 15:08:41
import main


if __name__ == '__main__':
	main.main()